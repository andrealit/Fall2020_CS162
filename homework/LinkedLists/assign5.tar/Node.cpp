/*********************************************************************
 ** Program Filename: Node.cpp
 ** Author: Andrea Tongsak
 ** Date: 11/24/2020
 ** Description: The Node class definitions
 ** Input: -
 ** Output: -
 *********************************************************************/

#include "Node.h"
